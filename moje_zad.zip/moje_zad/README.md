# POIT-Zadanie
Záverečné zadanie z POIT

Monitorovanie dát z mobilného telefónu

Gyroskóp a akcelerometer
